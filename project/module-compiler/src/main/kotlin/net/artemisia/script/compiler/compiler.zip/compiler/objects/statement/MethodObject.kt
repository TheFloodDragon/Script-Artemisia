package net.artemisia.script.compiler.runtime.compiler.objects.statement

import net.artemisia.script.common.ast.Expr
import net.artemisia.script.common.ast.State
import net.artemisia.script.compiler.Compiler
import net.artemisia.script.compiler.runtime.compiler.CompilerObject

class MethodObject(private val state : State.MethodDeclaration) : CompilerObject{

    //size|id|type|params|code|
    override fun compile(compiler: Compiler): ByteArray {
        val array = array()
        array.add(compiler.search(compiler.compileExpr(state.identifier)).toByte())
        println(array.toList())
        if (state.type == null){
            array.add(compiler.search(compiler.compileExpr(Expr.Identifier("Auto"))).toByte())
        }else{
            array.add(compiler.search(compiler.compileExpr(state.type!!)).toByte())
        }
        val params : ArrayList<Byte> = arrayListOf()
        for (i in state.params){
            params.addAll(compiler.compileState(i).toList())
        }
        array.add(params.size.toByte())
        array.addAll(params.toList())
        if (state.body != null){
            val codes : ArrayList<Byte> = arrayListOf()
            for (i in state.body!!.body){
                codes.addAll(compiler.compileState(i).toList())
            }
            array.add(codes.size.toByte())
            array.addAll(codes)
        }
        array.add(0,(array.size + 1).toByte())
        println(array.toList())
        return array.toByteArray()
    }
}