package net.artemisia.script.compiler.runtime.compiler

enum class ByteCodes(private val byte: Byte) {
    SetModule(0x01),
    LoadItem(0x02),
    LoadParent(0x03),
    LoadSub(0x04),
    Call(0x05),
    Ret(0x06),
    LoadModule(0x07),
    SetType(0x11),
    SaveVar(0x12),
    SaveCnt(0x13)
    ;
    //len|code|[index]|
    fun getCode(index : Int): ByteArray{
        val array : ArrayList<Byte> = arrayListOf()
        array.add(2)
        array.add(byte)
        array.add(index.toByte())
        return array.toByteArray()
    }
    fun getCode(): ByteArray{
        val array : ArrayList<Byte> = arrayListOf()
        array.add(1)
        array.add(byte)
        return array.toByteArray()
    }

}