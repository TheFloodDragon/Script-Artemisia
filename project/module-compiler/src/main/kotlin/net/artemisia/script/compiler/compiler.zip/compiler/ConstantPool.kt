package net.artemisia.script.compiler.runtime.compiler

import net.artemisia.script.compiler.runtime.compiler.objects.ObjectType

class ConstantPool(private val pool: MutableMap<Int, ArrayList<Byte>> = mutableMapOf()) {
    private var index = 0

    fun push(type: ObjectType, value: ByteArray): ByteArray {
        val list: ArrayList<Byte> = arrayListOf()

        list.add(type.byte)
        list.addAll(value.toList())

        pool[index] = list

        index += 1
        return list.toByteArray()
    }
    fun getter(type: ObjectType, value: ByteArray): ByteArray {
        val list: ArrayList<Byte> = arrayListOf()

        list.add(type.byte)
        list.addAll(value.toList())
        return list.toByteArray()
    }

    fun getPool(): MutableMap<Int, ArrayList<Byte>> {
        return pool
    }

    fun get(i: Int): ArrayList<Byte>? {
        return pool[i]
    }

    fun search(value: ArrayList<Byte>): Int? {
        val entry = pool.entries.find { it.value == value }
        return entry?.key
    }

    fun search(value: List<Byte>): Int? {
        val entry = pool.entries.find { it.value == value }
        return entry?.key
    }

}