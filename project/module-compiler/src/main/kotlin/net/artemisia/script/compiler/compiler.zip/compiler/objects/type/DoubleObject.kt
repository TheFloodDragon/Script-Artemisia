package net.artemisia.script.compiler.runtime.compiler.objects.type

import net.artemisia.script.compiler.Compiler
import net.artemisia.script.compiler.runtime.compiler.CompilerObject
import net.artemisia.script.compiler.runtime.compiler.objects.ObjectType
import java.nio.ByteBuffer

class DoubleObject(val double : Double) : CompilerObject{
    override fun compile(compiler: Compiler): ByteArray {

        val buffer = ByteBuffer.allocate(8)
        buffer.putDouble(double)
        val array : ArrayList<Byte> = arrayListOf()
        return run {

            array.add(9.toByte())
            array.add(ObjectType.DOUBLE.byte)
            array.addAll(buffer.array().toList())
            return@run array.toByteArray()
        }
    }

}