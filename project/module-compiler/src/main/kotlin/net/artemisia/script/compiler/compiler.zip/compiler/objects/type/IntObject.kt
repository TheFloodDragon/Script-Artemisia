package net.artemisia.script.compiler.runtime.compiler.objects.type

import net.artemisia.script.compiler.Compiler
import net.artemisia.script.compiler.runtime.compiler.CompilerObject
import net.artemisia.script.compiler.runtime.compiler.objects.ObjectType
import java.nio.ByteBuffer
import java.nio.ByteOrder

class IntObject(private val int: Int) : CompilerObject {
    override fun compile(compiler: Compiler): ByteArray {
        val buffer = ByteBuffer.allocate(8)
        buffer.order(ByteOrder.LITTLE_ENDIAN)
        buffer.putInt(int)
        val array : ArrayList<Byte> = arrayListOf()
        return run {
            array.add(9.toByte())
            array.add(ObjectType.INT.byte)
            array.addAll(buffer.array().toList())
            return@run array.toByteArray()
        }
    }
}