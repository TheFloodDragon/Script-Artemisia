package net.artemisia.script.compiler.runtime.compiler.objects

enum class ObjectType(val byte: Byte) {
    INT(0x1A),
    FLOAT(0x2A),
    DOUBLE(0x3A),
    STRING(0x4A),
    IDENTIFIER(0x5A),
    MODULE(0x6A)


}