package net.artemisia.script.compiler.runtime.compiler.objects.type

import net.artemisia.script.compiler.Compiler
import net.artemisia.script.compiler.runtime.compiler.CompilerObject
import net.artemisia.script.compiler.runtime.compiler.objects.ObjectType

class StringObject(private val str: String) : CompilerObject {
    override fun compile(compiler: Compiler): ByteArray {
        return run {
            val len = (str.length + 1).toByte()
            val str = str.toByteArray()
            val array: ArrayList<Byte> = arrayListOf()
            array.add(len)
            array.add(ObjectType.STRING.byte)
            array.addAll(str.toList())
            return@run array.toByteArray()
        }
    }
}