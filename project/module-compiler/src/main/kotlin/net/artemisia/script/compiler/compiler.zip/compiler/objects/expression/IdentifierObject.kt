package net.artemisia.script.compiler.runtime.compiler.objects.expression

import net.artemisia.script.common.ast.Expr
import net.artemisia.script.compiler.Compiler
import net.artemisia.script.compiler.runtime.compiler.CompilerObject
import net.artemisia.script.compiler.runtime.compiler.objects.type.StringObject

class IdentifierObject(val id : Expr.Identifier) : CompilerObject {
    override fun compile(compiler: Compiler): ByteArray {
        val array = array()
        array.addAll(StringObject(id.name).compile(compiler).toList())
        return array.toByteArray()
    }
}