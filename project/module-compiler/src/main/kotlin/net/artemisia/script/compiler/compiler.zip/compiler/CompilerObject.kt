package net.artemisia.script.compiler.runtime.compiler

import net.artemisia.script.compiler.Compiler




interface CompilerObject {
    fun array() : ArrayList<Byte>{
        return arrayListOf()
    }
    fun compile(compiler: Compiler) : ByteArray

}