package net.artemisia.script.compiler.runtime.compiler.objects.type

import net.artemisia.script.compiler.Compiler
import net.artemisia.script.compiler.runtime.compiler.CompilerObject

class ImportObject(private val path : String, private val calls : List<String>) : CompilerObject {

    //index|type|L(path)_C[]
    override fun compile(compiler: Compiler): ByteArray {
        val array = array()
        val str = "L(${path})_C$calls".toByteArray().toList()
        array.add(str.size.toByte())
        array.addAll(str)
        return array.toByteArray()
    }
}