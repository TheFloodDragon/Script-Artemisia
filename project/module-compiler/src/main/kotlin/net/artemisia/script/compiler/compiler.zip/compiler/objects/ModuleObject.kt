package net.artemisia.script.compiler.runtime.compiler.objects

import net.artemisia.script.common.ast.State
import net.artemisia.script.compiler.Compiler
import net.artemisia.script.compiler.runtime.compiler.CompilerObject
import net.artemisia.script.compiler.runtime.compiler.ConstantPool
import net.artemisia.script.compiler.runtime.compiler.objects.expression.IdentifierObject
import net.artemisia.script.compiler.runtime.compiler.objects.type.IntObject


class ModuleObject(val module : State.Module) : CompilerObject{
    /*
       <Magic[4]>
       <Version[4]>

       <Code Size>
       <Code>

       <function Size>
       <function>

       <Pool Size>
       <Constants Pool>
     */

    override fun compile(compiler: Compiler): ByteArray {
        val array = array()
        //Magic
        array.addAll(compiler.magic.toList())
        //Version
        array.addAll(compiler.version.toList())

        //Compile
        compiler.codes.addAll(compiler.compileState(module).toList())

        //Code
        array.addAll(IntObject(compiler.codes.size).compile(compiler).toList())
        array.addAll(compiler.codes)

        array.addAll(IntObject(compiler.methods.size).compile(compiler).toList())
        for (i in compiler.methods.keys){
            array.add(compiler.methods.size.toByte())
            array.addAll(compiler.methods[i]!!.toList())
        }

        array.addAll(IntObject(compiler.pool.getPool().size).compile(compiler).toList())
        for (i in compiler.pool.getPool().keys){
            array.add(compiler.pool.getPool().size.toByte())
            array.addAll(compiler.pool.getPool()[i]!!.toList())
        }
        return array.toByteArray()
    }
}

