package net.artemisia.script.compiler

import net.artemisia.script.common.ast.Expr
import net.artemisia.script.common.ast.State
import net.artemisia.script.common.expection.thrower
import net.artemisia.script.compiler.runtime.compiler.ByteCodes
import net.artemisia.script.compiler.runtime.compiler.ConstantPool
import net.artemisia.script.compiler.runtime.compiler.objects.ModuleObject
import net.artemisia.script.compiler.runtime.compiler.objects.ObjectType
import net.artemisia.script.compiler.runtime.compiler.objects.expression.IdentifierObject
import net.artemisia.script.compiler.runtime.compiler.objects.statement.MethodObject
import net.artemisia.script.compiler.runtime.compiler.objects.type.*
import java.io.File

class Compiler(val code : File) {
    val magic = byteArrayOf(
        0xBE.toByte(),
        0xEB.toByte(),
        0xAB.toByte(),
        0xEE.toByte()
    )
    val version = byteArrayOf(
        0x00,
        0x03,
        0x00,
        0x01
    )
    val pool = ConstantPool()
    private val module = Parser(code).parser()
    val codes : ArrayList<Byte> = arrayListOf()
    val methods : MutableMap<Int,ByteArray> = mutableMapOf()

    fun compileState(state : State) : ByteArray{
        return when(val state = state){
            is State.BlockState -> TODO()
            is State.CaseDeclaration -> TODO()
            is State.ClassDeclaration -> TODO()
            is State.DoWhileState -> TODO()
            is State.EmptyState -> {
                byteArrayOf()
            }
            is State.EnumState -> TODO()
            is State.EventState -> TODO()
            is State.ExpressionState -> {
                return when(state.expr){
                    is Expr.Identifier,is Expr.NullLiteral,is Expr.VoidLiteral,is Expr.NumericLiteral,is Expr.StringLiteral,is Expr.BooleanLiteral -> {
                        ByteCodes.LoadItem.getCode(search(compileExpr(state.expr)))
                    }
                    else -> {
                        compileExpr(state.expr)
                    }
                }
            }
            is State.ForState -> TODO()
            is State.IfState -> TODO()
            is State.ImportState -> {
                val code : ArrayList<Byte> = arrayListOf()
                if (state.file is Expr.Identifier){
                    val index : Int
                    if (state.all){
                        index = search(pool.push(ObjectType.MODULE, ImportObject((state.file as Expr.Identifier).name, arrayListOf("*")).compile(this)))

                    }else{
                        val loader : ArrayList<String> = arrayListOf()
                        for (i in state.obj){
                            if (i is Expr.Identifier){
                                loader.add(i.name)
                            }else{
                                thrower.RuntimeException("Error!!!Import not allow other unless id")
                            }
                        }
                        index = search(pool.push(ObjectType.MODULE, ImportObject((state.file as Expr.Identifier).name, loader).compile(this)))
                    }
                    code.addAll(ByteCodes.LoadModule.getCode(index).toList())
                }


                println(pool.getPool())
                code.toByteArray()
            }
            is State.MethodDeclaration -> {
                val code = MethodObject(state).compile(this)
                methods[methods.size] = code
                code
            }
            is State.Module -> {
                val code : ArrayList<Byte> = arrayListOf()
                code.addAll(ByteCodes.SetModule.getCode(search(compileExpr(state.id))).toList())
                for (i in module.body){
                    code.addAll(compileState(i).toList())
                }
                code.toByteArray()
            }
            is State.ReturnState -> {
                val code : ArrayList<Byte> = arrayListOf()
                if (state.argument != null) code.addAll(compileState(state.argument!!).toList())
                code.addAll(ByteCodes.Ret.getCode().toList())
                code.toByteArray()
            }
            is State.SwitchState -> TODO()
            is State.TryState -> TODO()
            is State.VariableDeclaration -> {
                val code : ArrayList<Byte> = arrayListOf()
                if (state.type != null) {
                    code.addAll(ByteCodes.SetType.getCode(search(compileExpr(state.type!!))).toList())
                }else code.addAll(ByteCodes.SetType.getCode(search(compileExpr(Expr.Identifier("Auto")))).toList())
                if (state.init != null) code.addAll(compileState(state.init!!).toList())
                if (state.const) {
                    code.addAll(ByteCodes.SaveCnt.getCode(search(compileExpr(state.id))).toList())
                }else {
                    code.addAll(ByteCodes.SaveVar.getCode(search(compileExpr(state.id))).toList())
                }
                code.toByteArray()
            }
            is State.VisitorState -> TODO()
            is State.WhileState -> TODO()
        }
    }
    fun compileExpr(expr: Expr,sub : Boolean = false) : ByteArray{

        return when(val expr = expr){
            is Expr.AssignmentExpr -> TODO()
            is Expr.BinaryExpr -> TODO()
            is Expr.BooleanLiteral -> TODO()
            is Expr.CallExpr -> {
                val code : ArrayList<Byte> = arrayListOf()
                for (i in expr.arguments){
                    code.addAll(compileState(i).toList())
                }
                code.addAll(ByteCodes.Call.getCode(search(compileExpr(expr.caller))).toList())
                code.toByteArray()
            }
            is Expr.GenericExpr -> TODO()
            is Expr.GroupExpr -> TODO()

            is Expr.Lambda -> TODO()
            is Expr.LogicalExpr -> TODO()
            is Expr.MemberExpr ->{
                val code : ArrayList<Byte> = arrayListOf()
                if (sub)
                    code.addAll(ByteCodes.LoadSub.getCode(search(compileExpr(expr.left))).toList())
                else
                    code.addAll(ByteCodes.LoadParent.getCode(search(compileExpr(expr.left))).toList())


                if (expr.right is Expr.MemberExpr)
                    code.addAll(compileExpr(expr.right).toList())
                else
                    code.addAll(ByteCodes.LoadSub.getCode(search(compileExpr(expr.right))).toList())
                code.toByteArray()
            }
            Expr.NullLiteral -> TODO()
            is Expr.Identifier -> {
                return pool.push(ObjectType.IDENTIFIER, IdentifierObject(expr).compile(this).toList().toByteArray())
            }
            is Expr.NumericLiteral -> {
                if ((expr.value.toDouble() % 1) == 0.0){

                    return pool.push(ObjectType.INT,IntObject(expr.value.toInt()).compile(this).toList().toByteArray())
                }else{
                    when (expr.value) {
                        is Float ->{
                            return pool.push(ObjectType.FLOAT, FloatObject(expr.value as Float).compile(this).toList().toByteArray())
                        }
                        else->{
                            return pool.push(ObjectType.DOUBLE, DoubleObject(expr.value as Double).compile(this).toList().toByteArray())
                        }
                    }
                }
            }
            is Expr.StringLiteral -> {
                return pool.push(ObjectType.STRING,StringObject(expr.value).compile(this).toList().toByteArray())
            }
            is Expr.ToExpr -> TODO()
            is Expr.UnaryExpr -> TODO()
            Expr.VoidLiteral -> TODO()
        }

    }
    fun search(byteArray: ByteArray): Int {
        return pool.search(byteArray.toList())!!
    }
    fun compile(): ByteArray {
        val file = File("${code.parent}${File.separator}${code.nameWithoutExtension}.apc")
        val codes = ModuleObject(module).compile(this)
        file.writeBytes(codes)
        file.mkdirs()
        file.createNewFile()
        return codes
    }
}